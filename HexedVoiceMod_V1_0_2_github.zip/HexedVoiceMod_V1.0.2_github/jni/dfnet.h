// DeepFilterNet noise suppression backend (neural, much stronger than RNNoise on changing noise such as keyboards, voices, traffic).
// Source: Rikorose/DeepFilterNet (MIT OR Apache-2.0), Android build by KaleyraVideo/AndroidDeepFilterNet (Apache-2.0):
//   libdf.so (armeabi-v7a, JNI exports) + deep_filter_mobile_model (tar.gz, ~8 MB).  Both files are shipped next to the mod, see README.
// How it is used: libdf.so only exports JNI functions, so the mod dlopen()s it and calls them with the game's JavaVM (aml->GetJavaVM()).
// ALL JNI work happens on ONE private worker thread that this file attaches to the JVM; the audio callback only moves 10 ms frames through
// two lock-free queues, so it never blocks and never touches JNI. If the worker is late for a frame the raw frame is used (counted as a miss);
// if more than 25 % of the frames are late the engine switches itself off and the caller falls back to RNNoise / Classic.
#pragma once
#ifndef VFX_NO_DEEPFILTER
#include <jni.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <unistd.h>
#include <thread>
#include <condition_variable>
#include <string>
#include <cstring>
#include <cstdio>

struct DfNet {
    static constexpr int FR = 480;                 // samples per frame (10 ms at 48 kHz); libdf.so wants 960 bytes of 16-bit mono
    static constexpr int QN = 16;                  // frames per queue
    typedef jlong (*new_t)(JNIEnv*, jobject, jbyteArray, jfloat);
    typedef jlong (*flen_t)(JNIEnv*, jobject, jlong);
    typedef jboolean (*setf_t)(JNIEnv*, jobject, jlong, jfloat);
    typedef jfloat (*proc_t)(JNIEnv*, jobject, jlong, jobject);
    typedef void (*free_t)(JNIEnv*, jobject, jlong);
    // state: 0 idle, 1 loading, 2 ready, 3 failed.  err (state 3): 1 no JavaVM, 2 thread attach failed, 3 libdf.so not found / cannot be loaded,
    // 4 libdf.so has no JNI exports, 5 model file not found, 6 newNative failed, 7 unexpected frame length, 8 too slow on this phone
    std::atomic<int> state{0}, err{0}, misses{0}, frames{0}, overflows{0};
    std::atomic<bool> bad{false}, stop{false};
    std::atomic<int> attenTenths{500};             // attenuation limit in 0.1 dB (applied by the worker thread)
    std::atomic<float> avgMs{0.f}, maxMs{0.f};
    JavaVM* vm = nullptr; std::string dirA, dirD;  // AndroidDataPath (where the files are put), DataPath (private, executable copy of libdf.so)
    std::thread th; std::mutex ctl, mu; std::condition_variable cv;
    int16_t inQ[QN][FR], outQ[QN][FR]; uint32_t inSeq[QN] = {}, outSeq[QN] = {};
    std::atomic<uint32_t> inW{0}, inR{0}, outW{0}, outR{0};
    int winFrames = 0, winMiss = 0;                // callback side only

    void configure(JavaVM* v, const char* androidDataDir, const char* dataDir) { vm = v; dirA = androidDataDir ? androidDataDir : ""; dirD = dataDir ? dataDir : ""; }
    bool ready() const { return state.load() == 2 && !bad.load(); }
    void setAtten(float db) { int t = (int)(db * 10.f + 0.5f); if (t < 0) t = 0; if (t > 1000) t = 1000; attenTenths = t; }

    void request() {                               // non-real-time threads only (menu / OnModLoad): starts the worker; a failed load can be retried
        std::lock_guard<std::mutex> g(ctl);
        int s = state.load(); if (s == 1 || s == 2) return;
        if (th.joinable()) th.join();
        state = 1; err = 0; bad = false; stop = false; misses = 0; frames = 0; overflows = 0; winFrames = winMiss = 0;
        inW = inR = outW = outR = 0; th = std::thread([this] { run(); });
    }
    void shutdown() { { std::lock_guard<std::mutex> g(ctl); stop = true; } cv.notify_all(); if (th.joinable()) th.join(); state = 0; }

    // ---- audio thread: push a frame (16-bit range floats), later pop the result with the same sequence number
    bool push(const float* in, uint32_t seq) {
        uint32_t w = inW.load(std::memory_order_relaxed), r = inR.load(std::memory_order_acquire);
        if (w - r >= (uint32_t)QN) { overflows++; return false; }
        int16_t* d = inQ[w % QN]; for (int i = 0; i < FR; i++) { float x = in[i]; d[i] = (int16_t)(x > 32767.f ? 32767.f : (x < -32768.f ? -32768.f : x)); }
        inSeq[w % QN] = seq; inW.store(w + 1, std::memory_order_release); cv.notify_one(); return true;
    }
    bool pop(uint32_t want, float* out) {          // discards results that are older than `want` (frames that arrived after their deadline)
        uint32_t r = outR.load(std::memory_order_relaxed);
        for (;;) {
            if (r == outW.load(std::memory_order_acquire)) { outR.store(r, std::memory_order_release); note(false); return false; }
            const int i = (int)(r % QN);
            if (outSeq[i] < want) { r++; continue; }
            if (outSeq[i] > want) { outR.store(r, std::memory_order_release); note(false); return false; }
            for (int k = 0; k < FR; k++) out[k] = (float)outQ[i][k]; outR.store(r + 1, std::memory_order_release); note(true); return true;
        }
    }
    void note(bool hit) {
        frames++; if (!hit) { misses++; winMiss++; }
        if (++winFrames >= 200) { if (winMiss * 4 > winFrames && !bad.load()) { bad = true; err = 8; state = 3; vlog("DeepFilterNet: %d of %d frames were late (phone too slow) - falling back to RNNoise / Classic", winMiss, winFrames); } winFrames = winMiss = 0; }
    }

private:
    static bool exists(const std::string& p) { struct stat st; return stat(p.c_str(), &st) == 0 && S_ISREG(st.st_mode) && st.st_size > 0; }
    std::string findFile(const char* name) const {
        const std::string c[] = { dirA + "/HexedVoiceMod/" + name, dirA + "/" + name, std::string("/storage/emulated/0/HexedVoiceMod/") + name, std::string("/sdcard/HexedVoiceMod/") + name };
        for (auto& p : c) if (exists(p)) return p;
        return "";
    }
    static bool copyFile(const std::string& from, const std::string& to) {
        struct stat a, b; if (stat(from.c_str(), &a) != 0) return false;
        if (stat(to.c_str(), &b) == 0 && b.st_size == a.st_size) return true;          // already copied
        FILE* i = fopen(from.c_str(), "rb"); if (!i) return false; FILE* o = fopen(to.c_str(), "wb"); if (!o) { fclose(i); return false; }
        char buf[65536]; size_t n; bool ok = true; while ((n = fread(buf, 1, sizeof buf, i)) > 0) if (fwrite(buf, 1, n, o) != n) { ok = false; break; }
        fclose(i); if (fclose(o) != 0) ok = false; return ok;
    }
    void fail(int e, const char* why) { err = e; state = 3; vlog("DeepFilterNet: %s", why); }
    void run() {
        JNIEnv* env = nullptr;
        if (!vm) { fail(1, "no JavaVM (aml->GetJavaVM() returned null)"); return; }
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) { fail(2, "cannot attach the worker thread to the JVM"); return; }
        // 1) load libdf.so: directly from where the user put it, else from a private copy (apps may not map code from /sdcard)
        void* h = nullptr; const std::string lib = findFile("libdf.so");
        if (lib.empty()) { vm->DetachCurrentThread(); fail(3, "libdf.so not found (put it in Android/data/<game>/files/HexedVoiceMod/)"); return; }
        h = dlopen(lib.c_str(), RTLD_NOW | RTLD_LOCAL);
        if (!h && !dirD.empty()) {
            const std::string d = dirD + "/hvm_df"; mkdir(dirD.c_str(), 0771); mkdir(d.c_str(), 0771);
            if (copyFile(lib, d + "/libdf.so")) h = dlopen((d + "/libdf.so").c_str(), RTLD_NOW | RTLD_LOCAL);
        }
        if (!h) { const char* e = dlerror(); vm->DetachCurrentThread(); fail(3, (std::string("dlopen libdf.so failed: ") + (e ? e : "?")).c_str()); return; }
        const char* P = "Java_com_rikorose_deepfilternet_NativeDeepFilterNet_";
        auto sym = [&](const char* n) { return dlsym(h, (std::string(P) + n).c_str()); };
        new_t fNew = (new_t)sym("newNative"); flen_t fLen = (flen_t)sym("getFrameLengthNative"); setf_t fAtt = (setf_t)sym("setAttenLimNative");
        proc_t fProc = (proc_t)sym("processFrameNative"); free_t fFree = (free_t)sym("freeNative");
        if (!fNew || !fLen || !fAtt || !fProc || !fFree) { vm->DetachCurrentThread(); fail(4, "libdf.so does not export the DeepFilterNet JNI functions"); return; }
        // 2) model file -> Java byte[] -> native state
        const std::string mp = findFile("deep_filter_mobile_model");
        if (mp.empty()) { vm->DetachCurrentThread(); fail(5, "deep_filter_mobile_model not found (put it next to libdf.so)"); return; }
        std::vector<jbyte> model; { FILE* f = fopen(mp.c_str(), "rb"); if (f) { fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); if (n > 0) { model.resize((size_t)n); if (fread(model.data(), 1, (size_t)n, f) != (size_t)n) model.clear(); } fclose(f); } }
        if (model.empty()) { vm->DetachCurrentThread(); fail(5, "cannot read deep_filter_mobile_model"); return; }
        jbyteArray arr = env->NewByteArray((jsize)model.size());
        if (!arr) { env->ExceptionClear(); vm->DetachCurrentThread(); fail(6, "out of Java memory for the model"); return; }
        env->SetByteArrayRegion(arr, 0, (jsize)model.size(), model.data()); std::vector<jbyte>().swap(model);
        jlong ptr = fNew(env, nullptr, arr, (jfloat)(attenTenths.load() / 10.f)); env->DeleteLocalRef(arr);
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (!ptr) { vm->DetachCurrentThread(); fail(6, "newNative failed (model rejected)"); return; }
        const jlong flen = fLen(env, nullptr, ptr);
        if (flen != FR * 2) { fFree(env, nullptr, ptr); vm->DetachCurrentThread(); char m[96]; snprintf(m, sizeof m, "unexpected frame length %lld bytes (need %d)", (long long)flen, FR * 2); fail(7, m); return; }
        static int16_t buf[FR]; memset(buf, 0, sizeof buf);
        jobject bb = env->NewDirectByteBuffer(buf, (jlong)(FR * 2)); if (bb) bb = env->NewGlobalRef(bb);
        if (!bb) { fFree(env, nullptr, ptr); vm->DetachCurrentThread(); fail(6, "cannot create the direct buffer"); return; }
        int curAtten = attenTenths.load(); state = 2; vlog("DeepFilterNet ready (frame %d samples, attenuation limit %.1f dB)", FR, curAtten / 10.0);
        // 3) worker loop
        while (!stop.load()) {
            const uint32_t r = inR.load(std::memory_order_relaxed), w = inW.load(std::memory_order_acquire);
            if (r == w) { std::unique_lock<std::mutex> lk(mu); cv.wait_for(lk, std::chrono::milliseconds(2)); continue; }
            memcpy(buf, inQ[r % QN], sizeof buf); const uint32_t sq = inSeq[r % QN]; inR.store(r + 1, std::memory_order_release);
            const int at = attenTenths.load(); if (at != curAtten) { curAtten = at; fAtt(env, nullptr, ptr, (jfloat)(at / 10.f)); }
            const auto t0 = std::chrono::steady_clock::now(); fProc(env, nullptr, ptr, bb);
            const float ms = std::chrono::duration<float, std::milli>(std::chrono::steady_clock::now() - t0).count();
            avgMs = avgMs.load() * 0.98f + ms * 0.02f; if (ms > maxMs.load()) maxMs = ms;
            const uint32_t ow = outW.load(std::memory_order_relaxed);
            if (ow - outR.load(std::memory_order_acquire) < (uint32_t)QN) { memcpy(outQ[ow % QN], buf, sizeof buf); outSeq[ow % QN] = sq; outW.store(ow + 1, std::memory_order_release); }
        }
        fFree(env, nullptr, ptr); env->DeleteGlobalRef(bb); vm->DetachCurrentThread();   // libdf.so stays loaded (Rust runtime), only the state is freed
        if (state.load() == 2) state = 0;
    }
};
static DfNet& g_df = *new DfNet;   // never destroyed: a joinable std::thread in a static would call std::terminate at process exit
#else
struct DfNet {
    std::atomic<int> state{0}, err{0}, misses{0}, frames{0}, overflows{0}; std::atomic<bool> bad{false}; std::atomic<float> avgMs{0.f}, maxMs{0.f};
    void configure(void*, const char*, const char*) {} bool ready() const { return false; } void setAtten(float) {} void request() {} void shutdown() {}
    bool push(const float*, uint32_t) { return false; } bool pop(uint32_t, float*) { return false; }
};
static DfNet& g_df = *new DfNet;   // never destroyed: a joinable std::thread in a static would call std::terminate at process exit
#endif
