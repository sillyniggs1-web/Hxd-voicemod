// Mock of Kaleyra's libdf.so for host tests: same six JNI exports. "Model": frames with rms < 1000 are noise (x0.05), louder frames pass.
// MOCKDF_SLEEP_US (env var) makes every frame take that long, to test the "phone too slow" fallback.
#include "jni.h"
#include <cmath>
#include <cstdlib>
#include <unistd.h>
struct St { float atten; int frames; };
extern "C" {
jlong Java_com_rikorose_deepfilternet_NativeDeepFilterNet_newNative(JNIEnv* e, jobject, jbyteArray a, jfloat at) { if (!a || e->GetArrayLength(a) < 16) return 0; return (jlong)(intptr_t) new St{ at, 0 }; }
jlong Java_com_rikorose_deepfilternet_NativeDeepFilterNet_getFrameLengthNative(JNIEnv*, jobject, jlong) { return getenv("MOCKDF_BADLEN") ? 480 : 960; }
jboolean Java_com_rikorose_deepfilternet_NativeDeepFilterNet_setAttenLimNative(JNIEnv*, jobject, jlong p, jfloat db) { ((St*)(intptr_t)p)->atten = db; return 1; }
jboolean Java_com_rikorose_deepfilternet_NativeDeepFilterNet_setPostFilterBetaNative(JNIEnv*, jobject, jlong, jfloat) { return 1; }
jfloat Java_com_rikorose_deepfilternet_NativeDeepFilterNet_processFrameNative(JNIEnv* e, jobject, jlong p, jobject bb) {
    St* s = (St*)(intptr_t)p; int16_t* d = (int16_t*)e->GetDirectBufferAddress(bb); double en = 0; for (int i = 0; i < 480; i++) en += (double)d[i] * d[i];
    const bool speech = sqrt(en / 480.0) > 1000.0; const float g = speech ? 1.f : powf(10.f, -s->atten / 20.f * 0.5f);   // quiet frames: -atten/2 dB (so the strength mapping is visible)
    for (int i = 0; i < 480; i++) d[i] = (int16_t)(d[i] * g); s->frames++;
    if (const char* sl = getenv("MOCKDF_SLEEP_US")) usleep((useconds_t)atoi(sl));
    return speech ? 20.f : -10.f; }
void Java_com_rikorose_deepfilternet_NativeDeepFilterNet_freeNative(JNIEnv*, jobject, jlong p) { delete (St*)(intptr_t)p; }
}
