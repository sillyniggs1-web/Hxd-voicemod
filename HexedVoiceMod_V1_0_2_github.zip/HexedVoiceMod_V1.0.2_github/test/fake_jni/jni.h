// Minimal stand-in for <jni.h> used ONLY by test/df_test.cpp and test/fake_jni/mock_libdf.cpp (host build, no Android NDK).
// It defines just the types and methods that jni/dfnet.h and the mock libdf.so use, with the same names and signatures as the real header.
#pragma once
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <vector>
typedef int32_t jint; typedef int64_t jlong; typedef float jfloat; typedef uint8_t jboolean; typedef int8_t jbyte; typedef jint jsize;
#define JNI_OK 0
struct _jobject { void* p = nullptr; jsize n = 0; }; typedef _jobject* jobject; typedef _jobject* jbyteArray;
struct JNIEnv {
    jbyteArray NewByteArray(jsize n) { auto* o = new _jobject; o->p = malloc((size_t)n); o->n = n; return o; }
    void SetByteArrayRegion(jbyteArray a, jsize s, jsize l, const jbyte* b) { memcpy((char*)a->p + s, b, (size_t)l); }
    jsize GetArrayLength(jbyteArray a) { return a->n; }
    jobject NewDirectByteBuffer(void* p, jlong n) { auto* o = new _jobject; o->p = p; o->n = (jsize)n; return o; }
    void* GetDirectBufferAddress(jobject o) { return o->p; }
    jobject NewGlobalRef(jobject o) { return o; }
    void DeleteGlobalRef(jobject) {}
    void DeleteLocalRef(jobject) {}
    bool ExceptionCheck() { return false; }
    void ExceptionClear() {}
};
struct JavaVM {
    int attached = 0, detached = 0; JNIEnv env;
    jint AttachCurrentThread(JNIEnv** e, void*) { attached++; *e = &env; return JNI_OK; }
    jint DetachCurrentThread() { detached++; return JNI_OK; }
};
