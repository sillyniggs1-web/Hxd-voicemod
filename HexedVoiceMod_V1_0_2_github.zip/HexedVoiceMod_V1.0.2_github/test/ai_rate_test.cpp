// Tests the AI (RNNoise) path plumbing at several microphone rates, with a stand-in for RNNoise (see fake_rnnoise/rnnoise.h):
// rate conversion to 48 kHz, delay alignment, speech-activity gate (closes between words, opens before speech arrives).
// Build: g++ -std=c++17 -O2 -ffast-math -fno-finite-math-only -DVFX_NO_RUBBERBAND -I test/fake_rnnoise test/ai_rate_test.cpp -o ai_rate_test
#define VFX_HOST_TEST 1
#define CFG_PATH "/tmp/hvm_test_ai.cfg"
#define OLD_CFG_PATH "/tmp/hvm_test_ai_old.cfg"
#include "../jni/voicefx_dsp.h"
#include <vector>
#include <cstdio>
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fails++; printf("  FAIL: "); printf(__VA_ARGS__); printf("\n"); } else { printf("  ok:   "); printf(__VA_ARGS__); printf("\n"); } } while (0)
static double rmsv(const std::vector<int16_t>& d, int a, int b) { double e = 0; for (int i = a; i < b; i++) e += (double)d[i] * d[i]; return sqrt(e / (b - a)); }
static double dbv(double x) { return 20 * log10(x + 1e-9); }
struct Sig { std::vector<int16_t> v; int sp0, sp1; };
// 1.5 s noise (rms ~ 400), 1 s speech-like (rms ~ 6000), 1.5 s noise
static Sig make(int rate) {
    Sig s; int n1 = rate * 3 / 2, n2 = rate, n3 = rate * 3 / 2; s.v.resize(n1 + n2 + n3); s.sp0 = n1; s.sp1 = n1 + n2; unsigned r = 12345;
    for (int i = 0; i < (int)s.v.size(); i++) {
        r = r * 1664525u + 1013904223u; double nz = ((r >> 8) / 8388608.0 - 1.0) * 690.0;                       // uniform noise, rms 400
        double sp = 0; if (i >= s.sp0 && i < s.sp1) { double t = i / (double)rate; sp = 6000 * sin(2 * M_PI * 180 * t) + 3000 * sin(2 * M_PI * 540 * t) + 1500 * sin(2 * M_PI * 1500 * t); }
        s.v[i] = (int16_t)(nz + sp);
    }
    return s;
}
static std::vector<int16_t> runAt(const std::vector<int16_t>& in, int rate, float amt, float noiseGain) {
    params_default(); vfx_prepare(rate); vfx_set(P_ENABLED, 0.f); vfx_set(P_NS_ON, 1.f); vfx_set(P_NS_ENGINE, 1.f); vfx_set(P_NS_AMT, amt);
    g_eng.cleanOnly = true; g_fake_noise_gain = noiseGain; auto out = in; int chunk = rate / 50;
    for (int p = 0; p < (int)out.size(); p += chunk) g_eng.process(out.data() + p, std::min(chunk, (int)out.size() - p));
    g_eng.cleanOnly = false; return out;
}
int main() {
    const int rates[] = { 8000, 16000, 24000, 48000 };
    for (int rate : rates) {
        printf("[AI @ %d Hz]\n", rate);
        const int L = 48000 / rate, D = 960 / L / 2;   // fake model has no internal delay: total delay = one frame = 480 / L samples
        Sig s = make(rate);
        auto o = runAt(s.v, rate, 1.0f, 0.05f);
        double nIn = rmsv(s.v, s.sp1 + rate / 2, (int)s.v.size()), nOut = rmsv(o, s.sp1 + rate / 2, (int)s.v.size());
        CHECK(dbv(nOut) - dbv(nIn) < -25, "noise after the phrase: %.1f dB (model -26 dB + speech gate)", dbv(nOut) - dbv(nIn));
        double vIn = rmsv(s.v, s.sp0 + rate / 4, s.sp1 - rate / 4), vOut = rmsv(o, s.sp0 + rate / 4 + 2 * D, s.sp1 - rate / 4 + 2 * D);
        CHECK(fabs(dbv(vOut) - dbv(vIn)) < 1.5, "speech level: %.2f dB", dbv(vOut) - dbv(vIn));
        int w = rate / 200;                                                                                      // first 5 ms of the speech
        double oIn = rmsv(s.v, s.sp0, s.sp0 + w), oOut = rmsv(o, s.sp0 + 2 * D, s.sp0 + 2 * D + w);
        CHECK(dbv(oOut) - dbv(oIn) > -3.0, "speech onset (first 5 ms) is not clipped by the gate: %.2f dB", dbv(oOut) - dbv(oIn));
        auto g = runAt(s.v, rate, 1.0f, 1.0f);                                                                   // model does nothing -> only the speech gate acts
        double gOut = rmsv(g, s.sp1 + rate / 2, (int)s.v.size());
        CHECK(dbv(gOut) - dbv(nIn) < -25, "speech gate alone closes the gaps: %.1f dB (floor -36 dB at strength 1)", dbv(gOut) - dbv(nIn));
        auto g2 = runAt(s.v, rate, 0.0f, 1.0f); double g2Out = rmsv(g2, s.sp1 + rate / 2, (int)s.v.size());
        CHECK(dbv(g2Out) - dbv(nIn) < -4 && dbv(g2Out) - dbv(nIn) > -9, "strength 0: gate depth %.1f dB (-6 dB)", dbv(g2Out) - dbv(nIn));
    }
    printf("[44100 Hz: not an integer ratio -> Classic fallback]\n");
    { Sig s = make(44100); auto o = runAt(s.v, 44100, 1.0f, 0.05f); double nIn = rmsv(s.v, s.sp1 + 22050, (int)s.v.size()), nOut = rmsv(o, s.sp1 + 22050, (int)s.v.size());
      CHECK(AiNs::ratioFor(44100) == 0, "ratioFor(44100) = 0"); CHECK(dbv(nOut) - dbv(nIn) < -10, "Classic still reduces the noise: %.1f dB", dbv(nOut) - dbv(nIn)); }
    printf(fails ? "\n%d FAILED\n" : "\nALL TESTS PASSED (0 failed)\n", fails); return fails ? 1 : 0;
}
