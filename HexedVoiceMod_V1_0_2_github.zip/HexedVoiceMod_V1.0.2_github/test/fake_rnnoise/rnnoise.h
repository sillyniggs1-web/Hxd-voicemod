// Stand-in for RNNoise used ONLY by test/ai_rate_test.cpp (the real library is downloaded by the workflow).
// Same API as xiph/rnnoise v0.1.1: 480-sample frames, int16-range floats, returns the VAD probability.
// "Model": frames with rms < 1000 are noise (attenuated by g_fake_noise_gain, VAD 0.02), louder frames are speech (passed, VAD 0.95).
#pragma once
#include <cmath>
#include <cstring>
struct DenoiseState { int dummy; };
inline float g_fake_noise_gain = 0.05f;
inline DenoiseState* rnnoise_create(void*) { return new DenoiseState{0}; }
inline void rnnoise_destroy(DenoiseState* s) { delete s; }
inline float rnnoise_process_frame(DenoiseState*, float* out, const float* in) {
    double e = 0; for (int i = 0; i < 480; i++) e += (double)in[i] * in[i];
    const bool speech = std::sqrt(e / 480.0) > 1000.0;
    for (int i = 0; i < 480; i++) out[i] = in[i] * (speech ? 1.f : g_fake_noise_gain);
    return speech ? 0.95f : 0.02f;
}
