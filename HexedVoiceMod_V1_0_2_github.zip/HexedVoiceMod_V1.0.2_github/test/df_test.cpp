// Host test of the DeepFilterNet backend (jni/dfnet.h) against a mock libdf.so (test/fake_jni/mock_libdf.cpp) and a mock JNI (test/fake_jni/jni.h):
// loading, worker thread, frame queues, rate conversion, strength mapping, fallbacks (missing files, bad frame length, phone too slow).
// Runs in real time (about 25 s). Build:  g++ -std=c++17 -O2 -shared -fPIC -I test/fake_jni test/fake_jni/mock_libdf.cpp -o /tmp/dftest/libdf.so
//         g++ -std=c++17 -O2 -ffast-math -fno-finite-math-only -DVFX_NO_RUBBERBAND -DVFX_NO_RNNOISE -I test/fake_jni test/df_test.cpp -o df_test -ldl -lpthread
#define VFX_HOST_TEST 1
#define CFG_PATH "/tmp/hvm_test_df.cfg"
#define OLD_CFG_PATH "/tmp/hvm_test_df_old.cfg"
#include "../jni/voicefx_dsp.h"
#include <vector>
#include <cstdio>
#include <thread>
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fails++; printf("  FAIL: "); printf(__VA_ARGS__); printf("\n"); } else { printf("  ok:   "); printf(__VA_ARGS__); printf("\n"); } } while (0)
static JavaVM g_vm;
static double rmsv(const std::vector<int16_t>& d, int a, int b) { double e = 0; for (int i = a; i < b; i++) e += (double)d[i] * d[i]; return sqrt(e / (b - a)); }
static double dbv(double x) { return 20 * log10(x + 1e-9); }
struct Sig { std::vector<int16_t> v; int sp0, sp1; };
static Sig make(int rate) {       // 1 s noise (rms ~400), 0.6 s speech-like (~6000), 1.2 s noise
    Sig s; int n1 = rate, n2 = rate * 3 / 5, n3 = rate * 6 / 5; s.v.resize(n1 + n2 + n3); s.sp0 = n1; s.sp1 = n1 + n2; unsigned r = 777;
    for (int i = 0; i < (int)s.v.size(); i++) { r = r * 1664525u + 1013904223u; double nz = ((r >> 8) / 8388608.0 - 1.0) * 690.0, sp = 0;
        if (i >= s.sp0 && i < s.sp1) { double t = i / (double)rate; sp = 6000 * sin(2 * M_PI * 180 * t) + 3000 * sin(2 * M_PI * 540 * t) + 1500 * sin(2 * M_PI * 1500 * t); } s.v[i] = (int16_t)(nz + sp); }
    return s; }
static bool waitDone(int ms) { for (int i = 0; i < ms / 10; i++) { int s = g_df.state.load(); if (s == 2 || s == 3) return true; std::this_thread::sleep_for(std::chrono::milliseconds(10)); } return false; }
static std::vector<int16_t> runPaced(const std::vector<int16_t>& in, int rate, float amt) {   // real time, like a phone that keeps up
    params_default(); vfx_prepare(rate); vfx_set(P_ENABLED, 0.f); vfx_set(P_NS_ON, 1.f); vfx_set(P_NS_AMT, amt); vfx_set(P_NS_ENGINE, 2.f);
    waitDone(3000); g_eng.cleanOnly = true; auto out = in; int chunk = rate / 50;
    for (int p = 0; p < (int)out.size(); p += chunk) { g_eng.process(out.data() + p, std::min(chunk, (int)out.size() - p)); std::this_thread::sleep_for(std::chrono::milliseconds(20)); }
    g_eng.cleanOnly = false; return out; }
static void setup(const char* dir, bool lib, bool model) {
    char c[256]; snprintf(c, sizeof c, "rm -rf %s %s_data; mkdir -p %s %s_data", dir, dir, dir, dir); system(c);
    if (lib) { snprintf(c, sizeof c, "cp /tmp/dftest/libdf.so %s/libdf.so", dir); system(c); }
    if (model) { snprintf(c, sizeof c, "head -c 4096 /dev/urandom > %s/deep_filter_mobile_model", dir); system(c); }
    g_df.shutdown(); g_df.configure(&g_vm, dir, (std::string(dir) + "_data").c_str()); }
int main() {
    const int rates[] = { 48000, 16000, 8000 };
    for (int rate : rates) {
        printf("[DeepFilterNet @ %d Hz]\n", rate); setup("/tmp/dfa", true, true); unsetenv("MOCKDF_SLEEP_US"); unsetenv("MOCKDF_BADLEN");
        Sig s = make(rate); auto o = runPaced(s.v, rate, 1.0f);
        CHECK(g_df.state.load() == 2, "library loaded, worker running (state %d, err %d)", g_df.state.load(), g_df.err.load());
        double nIn = rmsv(s.v, s.sp1 + rate / 2, (int)s.v.size()), nOut = rmsv(o, s.sp1 + rate / 2, (int)s.v.size());
        CHECK(dbv(nOut) - dbv(nIn) < -25, "noise after the phrase: %.1f dB", dbv(nOut) - dbv(nIn));
        const int D = 1440 / (48000 / rate);      // pipeline delay: 1 frame of buffering + 2 frames of worker slack (the mock model has no delay of its own)
        double vIn = rmsv(s.v, s.sp0 + rate / 8, s.sp1 - rate / 8), vOut = rmsv(o, s.sp0 + rate / 8 + D, s.sp1 - rate / 8 + D);
        CHECK(fabs(dbv(vOut) - dbv(vIn)) < 1.5, "speech level: %.2f dB", dbv(vOut) - dbv(vIn));
        CHECK(g_df.frames.load() > 100 && g_df.misses.load() * 20 < g_df.frames.load(), "frames %d, late %d (< 5%%)", g_df.frames.load(), g_df.misses.load());
        CHECK(!g_df.bad.load(), "not flagged as too slow");
        if (rate == 48000) {
            auto o0 = runPaced(s.v, rate, 0.0f); double n0 = rmsv(o0, s.sp1 + rate / 2, (int)s.v.size());
            CHECK(g_df.state.load() == 2 && !g_df.bad.load(), "second run on the same library (engine restarted, stale frames in the queues): still DeepFilterNet, late %d of %d", g_df.misses.load(), g_df.frames.load());
            CHECK(dbv(n0) - dbv(nIn) < -4.5 && dbv(n0) - dbv(nIn) > -9, "strength 0 = attenuation limit 12 dB: %.1f dB (mock: half of the limit = 6 dB)", dbv(n0) - dbv(nIn)); }
        g_df.shutdown(); CHECK(g_vm.attached == g_vm.detached, "worker thread attached %d / detached %d", g_vm.attached, g_vm.detached);
    }
    printf("[failures fall back to Classic]\n");
    { Sig s = make(48000); double nIn = rmsv(s.v, s.sp1 + 24000, (int)s.v.size());
      struct Case { const char* name; bool lib, model; const char* env; int err; } cs[] = { { "no libdf.so", false, true, nullptr, 3 }, { "no model file", true, false, nullptr, 5 }, { "unexpected frame length", true, true, "MOCKDF_BADLEN", 7 } };
      for (auto& c : cs) { setup("/tmp/dfb", c.lib, c.model); unsetenv("MOCKDF_BADLEN"); if (c.env) setenv(c.env, "1", 1);
        auto o = runPaced(s.v, 48000, 1.0f); CHECK(g_df.state.load() == 3 && g_df.err.load() == c.err, "%s: state %d, error code %d (expected %d)", c.name, g_df.state.load(), g_df.err.load(), c.err);
        CHECK(dbv(rmsv(o, s.sp1 + 24000, (int)s.v.size())) - dbv(nIn) < -10, "%s: Classic still reduces the noise: %.1f dB", c.name, dbv(rmsv(o, s.sp1 + 24000, (int)s.v.size())) - dbv(nIn)); }
      unsetenv("MOCKDF_BADLEN"); }
    printf("[phone too slow]\n");
    { setup("/tmp/dfc", true, true); setenv("MOCKDF_SLEEP_US", "25000", 1);         // 25 ms per 10 ms frame
      Sig s = make(48000); auto o = runPaced(s.v, 48000, 1.0f); unsetenv("MOCKDF_SLEEP_US");
      CHECK(g_df.bad.load() && g_df.err.load() == 8, "flagged as too slow (late frames %d of %d), error code %d", g_df.misses.load(), g_df.frames.load(), g_df.err.load());
      double nIn = rmsv(s.v, s.sp1 + 24000, (int)s.v.size()), nOut = rmsv(o, s.sp1 + 24000, (int)s.v.size());
      CHECK(dbv(nOut) - dbv(nIn) < -10, "falls back to Classic, noise after the phrase: %.1f dB", dbv(nOut) - dbv(nIn));
      g_df.shutdown(); CHECK(g_vm.attached == g_vm.detached, "worker joined cleanly (attached %d / detached %d)", g_vm.attached, g_vm.detached); }
    printf(fails ? "\n%d FAILED\n" : "\nALL TESTS PASSED (0 failed)\n", fails); return fails ? 1 : 0;
}
