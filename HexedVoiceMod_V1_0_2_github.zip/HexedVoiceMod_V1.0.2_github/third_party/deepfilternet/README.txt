DeepFilterNet files for the "DeepFilterNet" noise suppression engine (HexedVoiceMod 1.0.2+)

libdf.so                  armeabi-v7a (32-bit ARM) build of DeepFilterNet with JNI exports, from KaleyraVideo/AndroidDeepFilterNet (Apache-2.0)
deep_filter_mobile_model  DeepFilterNet mobile model (tar.gz, ~8 MB), same repository
DeepFilterNet itself is by Hendrik Schroeter (Rikorose/DeepFilterNet, MIT OR Apache-2.0).

Install: copy BOTH files into  Android/data/<game package>/files/HexedVoiceMod/  (create the folder), next to nothing else needed.
The mod finds them there (also accepted: that files/ folder itself, or /storage/emulated/0/HexedVoiceMod/). The workflow already puts them in the
HexedVoiceMod/ folder of its download.  Then in the menu: Clean tab -> Noise suppression ON -> Engine: DeepFilterNet.
